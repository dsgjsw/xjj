function [k2] = Kzhi(I1)

% for i=1:16
%     k1=diag(I1,5*i-5);
%     k2=diag(I1,-5*i);
%     K1(i)=floor(mean(k1));
%     K2(i)=floor(mean(k2));
% end
% K=[K1 K2];

[M,N]=size(I1);
k1=zeros(1,M);
for i=1:M-1
    k1(i)=floor(mean(bitxor(uint8(I1(i,:)),uint8(I1(i+1,:)))));
end
   n=length(k1);
   n1=fix(n/20);
   for i=1:n1
%        k1(i)=floor(mean(20*(i-1)+1:20*i));
        k2(i)=floor(mean(k1(20*(i-1)+1:20*i)));
   end
end

