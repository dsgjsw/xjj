function [I1_6_1_3] = jiemi(I1,I1_6,x1,x2,position,x1_0)
[M N]=size(I1);
I1_6_5=I1_6(:);
I1_6_4=zeros(8*M*N,1);
 for i=1:M*N
     w= I1_6_5(i);
     for z = 1:8
         rem = mod(w,2);
         I1_6_4(8*(i-1)+(9-z)) = rem;
         w = fix(w/2);
     end 
 end
I1_6_3=zeros(2*M*N,1);
for i=1:2*M*N
    I1_6_3(i)=I1_6_4(4*(i-1)+1)*2^3+I1_6_4(4*(i-1)+2)*2^2+I1_6_4(4*(i-1)+3)*2+I1_6_4(4*i);
end

I1_6_2=zeros(2*M*N,1);
for i=1:2*M*N
    if x2(i)==0
        I1_6_2(i)=bitxor(I1_6_3(i),x1(i));
    end
    if x2(i)==1
        I1_6_2(i)=I1_6_3(i)-x1(i);
        if I1_6_2(i)<0
            I1_6_2(i)=I1_6_2(i)+16;
        end
    end
    if x2(i)==2
        I1_6_2(i)=I1_6_3(i)+x1(i);
        if I1_6_2(i)>15
            I1_6_2(i)=I1_6_2(i)-16;
        end
    end
    if x2(i)==3
        if I1_6_3(i)>7
           I1_6_2(i)=I1_6_3(i)-8; 
        end
        if I1_6_3(i)<8
            I1_6_2(i)=I1_6_3(i)+8;
        end
    end
end
I1_6_1(position)=I1_6_2;
I1_6_1=I1_6_1';

I1_6_1_0=zeros(8*M*N,1);
    for i=1:2*M*N
        w=I1_6_1(i);
        for z=1:4
            rem1=mod(w,2);
            I1_6_1_0(4*(i-1)+(5-z))=rem1;
            w=fix(w/2);
        end
    end
    for i=1:2*M*N
        [p n]=sort(x1_0(4*(i-1)+1:4*i));
        q=I1_6_1_0(4*(i-1)+1:4*i);
        a(n)=q;
        I1_6_1_1(4*(i-1)+1:4*i)=a;
    end
    I1_6_1_1=I1_6_1_1';
I1_6_1_2=zeros(2*M*N,1);
for i=1:2*M*N
    I1_6_1_2(i)=I1_6_1_1(4*(i-1)+1)*2^3+I1_6_1_1(4*(i-1)+2)*2^2+I1_6_1_1(4*(i-1)+3)*2+I1_6_1_1(4*i);
end 

for i=1:M*N

    I1_6_1_3(i)=I1_6_1_2(2*(i-1)+1)+I1_6_1_2(2*i)*16;
end
I1_6_1_3=reshape(I1_6_1_3,[M,N]);

end

