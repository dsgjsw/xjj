function [x1,x2,x3,x4,x5,x6,I1_6,I2_6,I3_6,position,position1,position2,x1_0,x2_0,x3_0,II1] = jiami(M,N,I1,I2,I3,K1,K2,K3,Kr)
[x1_0 x1_1 I1_1 ]=logistic(I1,Kr,K1);
[x2_0 x2_1 I2_1]=logistic(I2,Kr,K2);
[x3_0 x3_1 I3_1]=logistic(I3,Kr,K3);

[B position]=sort(x1_1);
I1_2=I1_1(position);
[B1 position1]=sort(x2_1);
I2_2=I2_1(position1);
[B2 position2]=sort(x3_1);
I3_2=I3_1(position2);

len=M+K1(16)+K1(17)+K1(18)+K1(19)+K1(20)+Kr;
% x(1)=bitxor(bitxor(bitxor(bitxor(bitxor(K1(1),K1(7)),Kr),K1(13)),K1(19)),floor(mean(I1(:))))/256+1+mean(I1(:))/256*10^-5;
% x(2)=bitxor(bitxor(bitxor(bitxor(bitxor(K1(1),K1(10)),Kr),K1(19)),K1(28)),floor(mean(I1(:))))/256+2+mean(I1(:))/256*10^-5;
% x(3)=bitxor(bitxor(bitxor(bitxor(bitxor(K1(1),K1(5)),Kr),K1(15)),K1(30)),floor(mean(I1(:))))/256+3+mean(I1(:))/256*10^-5;
x(1)=bitxor(bitxor(bitxor(bitxor(bitxor(K1(1),K1(4)),Kr),K1(7)),K1(10)),floor(mean(I1(:))))/256+1+mean(I1(:))/256*10^-5;
x(2)=bitxor(bitxor(bitxor(bitxor(bitxor(K1(2),K1(5)),Kr),K1(8)),K1(11)),floor(mean(I1(:))))/256+2+mean(I1(:))/256*10^-5;
x(3)=bitxor(bitxor(bitxor(bitxor(bitxor(K1(3),K1(6)),Kr),K1(9)),K1(12)),floor(mean(I1(:))))/256+3+mean(I1(:))/256*10^-5;

[T,Y]=ode45(@chao_SimpleChen,0:0.01:5500,[x(1),x(2),x(3)]);

x1=mod(fix(Y(len+1:end,1)*10^10),16);
x2=mod(fix(x1_0(1:2*M*N)*10^16),3);
x3=mod(fix(Y(len+1:end,2)*10^10),16);
x4=mod(fix(x2_0(1:2*M*N)*10^16),3);
x5=mod(fix(Y(len+1:end,3)*10^10),16);
x6=mod(fix(x3_0(1:2*M*N)*10^16),3);
I1_6=huiduzhihuan(I1,I1_2,x1,x2);
I2_6=huiduzhihuan(I2,I2_2,x3,x4);
I3_6=huiduzhihuan(I3,I3_2,x5,x6);
II1(:,:,1)=I1_6;
II1(:,:,2)=I2_6;
II1(:,:,3)=I3_6;
end

