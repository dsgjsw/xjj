function [I1_6] = huiduzhihuan(I1,I1_2,x1,x2)
[M,N]=size(I1);
I1_3=zeros(2*M*N,1);
for i=1:2*M*N
    if x2(i)==0
        I1_3(i)=bitxor(I1_2(i),x1(i));
    end
    if x2(i)==1
        I1_3(i)=I1_2(i)+x1(i);
        if I1_3(i)>15
            I1_3(i)=I1_3(i)-16;
        end
    end
    if x2(i)==2
        I1_3(i)=I1_2(i)-x1(i);
        if I1_3(i)<0
            I1_3(i)=16+I1_3(i);
        end
    end
    if x2(i)==3
        if I1_2(i)>7
           I1_3(i)=I1_2(i)-8; 
        end
        if I1_2(i)<8
            I1_3(i)=I1_2(i)+8;
        end
    end
end
I1_4=zeros(8*M*N,1);
    for i=1:2*M*N
        w=I1_3(i);
        for z=1:4
            rem1=mod(w,2);
            I1_4(4*(i-1)+(5-z))=rem1;
            w=fix(w/2);
        end
    end
    I1_5=zeros(M*N,1);
    for i=1:M*N
        I1_5(i)=I1_4(8*(i-1)+1)*2^7+I1_4(8*(i-1)+2)*2^6+I1_4(8*(i-1)+3)*2^5+I1_4(8*(i-1)+4)*2^4+I1_4(8*(i-1)+5)*2^3 ...
        +I1_4(8*(i-1)+6)*2^2+I1_4(8*(i-1)+7)*2+I1_4(8*(i-1)+8);    
    end
    I1_6=reshape(I1_5,[M,N]);

end

