function [x1 x3 I7] = logistic(I1,Kr,K1)
[M,N]=size(I1);
x1=bitxor(floor(mean(I1(:))),Kr)/256+mean(I1(:))/256*10^-5;
% u1=3.9+bitxor(bitxor(bitxor(bitxor(bitxor(K1(1),K1(6)),K1(21)),K1(11)),K1(26)),Kr)/256*0.1;
% x2=x1+bitxor(bitxor(bitxor(bitxor(K1(1),K1(3)),K1(20)),K1(5)),Kr)/256*10^-10;
% u2=3.9+bitxor(bitxor(bitxor(bitxor(bitxor(K1(1),K1(7)),K1(14)),K1(21)),K1(28)),Kr)/256*0.1;
% len=K1(1)+K1(2)+K1(17)+K1(3)+K1(18)+Kr;
u1=3.9+bitxor(bitxor(bitxor(bitxor(bitxor(K1(1),K1(2)),K1(3)),K1(4)),K1(5)),Kr)/256*0.1;
x2=x1+bitxor(bitxor(bitxor(bitxor(bitxor(K1(11),K1(12)),K1(13)),K1(14)),K1(15)),Kr)/256*10^-10;
u2=3.9+bitxor(bitxor(bitxor(bitxor(bitxor(K1(6),K1(7)),K1(8)),K1(9)),K1(10)),Kr)/256*0.1;
len=M+K1(16)+K1(17)+K1(18)+K1(19)+K1(20)+Kr;


for i=2:len
    x1=u1*x1*(1-x1);
    x2=u2*x2*(1-x2);
end
lenmn=8*M*N;
x1(1)=x1;
x2(1)=x2;
for i=2:lenmn
    x1(i)=u1*x1(i-1)*(1-x1(i-1));
    x2(i)=u2*x2(i-1)*(1-x2(i-1));
end

x3=x2(1:2*M*N);

I4 = zeros(2*M*N,1);
PlainImg=I1(:);
Imgsize=M*N; 
for i=1:Imgsize
    num2decomposed = PlainImg(i);
    for z = 1:2
        rem = mod(num2decomposed,16);
        I4(2*(i-1)+z) = rem;
        num2decomposed = fix(num2decomposed/16);
    end 
end

    I5=zeros(8*M*N,1);
    I6=zeros(8*M*N,1);
    for i=1:2*M*N
        w=I4(i);
        for z=1:4
            rem1=mod(w,2);
            I5(4*(i-1)+(5-z))=rem1;
            w=fix(w/2);
        end
        [p n]=sort(x1(4*(i-1)+1:4*i));
        q=I5(4*(i-1)+1:4*i);
        I6(4*(i-1)+1:4*i)=q(n);
    end
I7=zeros(2*M*N,1);
for i=1:2*M*N
    I7(i)=I6(4*(i-1)+1)*2^3+I6(4*(i-1)+2)*2^2+I6(4*(i-1)+3)*2+I6(4*i);
end

end

