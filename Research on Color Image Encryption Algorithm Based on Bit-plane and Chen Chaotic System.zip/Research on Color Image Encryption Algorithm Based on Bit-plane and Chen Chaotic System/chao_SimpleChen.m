function f=chao_SimpleChen(t,y)
global c
f=zeros(3,1);
f(1)=35*(y(2)-y(1));
f(2)=-7*y(1)-y(1)*y(3)+28*y(2);
f(3)=y(1)*y(2)-3*y(3);
end